Caleb Hammack

This is my readme for project 3. I was able to complete all the tasks to the best of my knowledge.
No known bugs when zooming in or out. I also did NOT do the bonus part.

I used one late day.